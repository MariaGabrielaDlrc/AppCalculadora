package com.example.trabajo1gabriela;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText edtCaja1, edtCaja2;
    TextView txtResultado,txtOperacion;
    AppCompatButton btnCalcular;
    int dato=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        edtCaja1=findViewById(R.id.edtCaja1);
        edtCaja2=findViewById(R.id.edtCaja2);
        txtResultado=findViewById(R.id.txtResultado);
        txtOperacion=findViewById(R.id.txtOperacion);
        btnCalcular=findViewById(R.id.btnCalcular);

        dato = getIntent().getIntExtra("data",0);
        if (dato==1){
            txtOperacion.setText("+");
        }else if(dato==2){
            txtOperacion.setText("-");
        }else if(dato==3){
            txtOperacion.setText("*");
        }else if(dato==4){
            txtOperacion.setText("/");
        }

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularSuma();
            }
        });


    }

    private void calcularSuma() {
        String n1 = edtCaja1.getText().toString();
        String n2 = edtCaja2.getText().toString();

        if (n1.isEmpty() || n2.isEmpty()){
            //mensaje de error
            Toast.makeText(MainActivity.this,"Los campos no pueden estar vacios",Toast.LENGTH_LONG).show();
        }else{
            int val1 = Integer.parseInt(n1);
            int val2 = Integer.parseInt(n2);

            if (val1<0 || val2<0 ){
                Toast.makeText(MainActivity.this,"Los numeros deben ser positivos",Toast.LENGTH_LONG).show();
            }else{
                int resultado=0;
                if (dato==1){
                    resultado = val1+val2;
                }else if(dato==2){
                    resultado = val1-val2;
                }else if(dato==3){
                    resultado = val1*val2;
                }else if(dato==4){
                    resultado = val1/val2;
                }

                txtResultado.setText(resultado+"");
            }
        }


    }
}